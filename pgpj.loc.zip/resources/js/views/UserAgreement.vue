<template>
  <div>
    <h1>User Agreement</h1>
    <a-empty />
  </div>
</template>

<script></script>
