<template>
  <div class="upload">
    <h1>Upload page</h1>
    <a-empty />
  </div>
</template>

<script></script>
