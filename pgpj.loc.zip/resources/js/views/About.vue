<template>
  <div class="about">
    <h1>About page</h1>
    <a-empty />
  </div>
</template>

<script></script>
