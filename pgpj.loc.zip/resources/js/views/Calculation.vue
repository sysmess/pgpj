<template>
  <div class="calculation">
    <h1>Calculation page</h1>
    <a-empty />
  </div>
</template>

<script></script>
