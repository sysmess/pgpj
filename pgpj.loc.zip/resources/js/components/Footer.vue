<template xmlns="http://www.w3.org/1999/html">
  <div id="footer">
    <a-divider />
    <a-row>
      <a-col :span="12">
        <div id="social" class="left">Поделиться:
            <a-icon type="facebook" theme="filled" />
            <a-icon type="instagram" theme="filled" />
            <a-icon type="twitter-square" theme="filled" />
        </div>
      </a-col>
      <a-col :span="12">
        <div id="copyright" class="right">
            <span>Copyright @ 2021</span>
             <a-divider type="vertical"  />
             <router-link to="/agreement">Пользовательское соглашение</router-link>
        </div>
      </a-col>
    </a-row>
  </div>
</template>

<script>
export default {
  name: "Footer",
};
</script>

<style scoped>
.right {
    text-align: right;
}
.left{
    text-align: left;
}
.icons-list >>> .anticon {
    margin-right: 6px;
    font-size: 24px;
}
</style>
