<template>
    <div id="compareChart" class="container">

        <div>
            <compare-horizontal-bar-chart label="CompareHorizontalBarChart" style="height: auto" />
        </div>

    </div>
</template>

<script>
import CompareHorizontalBarChart from "../charts/CompareHorizontalBarChart";
import {mapGetters} from "vuex";

export default {
  components: {
    CompareHorizontalBarChart,
  },
  computed: mapGetters(['Status', 'Classes', 'ClassesCount', 'SelectedRegion', 'SelectedRegionDataFiltered','RussiaDataFiltered'])

};
</script>

<style scoped>

</style>
